EXECUTIVE INTELLIGENCE OVERLAY

1. Unzip this folder.
2. Open chrome://extensions
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the executive-intelligence-overlay folder.
6. Open an executive profile, company bio, or news article.
7. Click the extension and choose Analyze Current Page.
