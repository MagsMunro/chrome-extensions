// Future saved people utilities
const PeopleStore = {};
