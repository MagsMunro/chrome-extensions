const $ = id => document.getElementById(id);
let brief = null;

function clean(s){ return (s || "").replace(/\s+/g," ").trim(); }

function inferExpertise(text){
  const map = {
    "Executive Recruiting":["executive recruiting","executive talent","leadership hiring"],
    "Talent Intelligence":["talent intelligence","market intelligence","talent insights"],
    "Engineering":["engineering","technical","software"],
    "AI":["artificial intelligence","machine learning","generative ai"],
    "Product":["product","platform"],
    "Go-to-Market":["sales","marketing","go-to-market"],
    "Operations":["operations","program management","shared services"],
    "Strategy":["strategy","strategic","workforce planning"]
  };
  const lower = text.toLowerCase();
  return Object.entries(map)
    .filter(([_,terms]) => terms.some(t => lower.includes(t)))
    .map(([k]) => k)
    .slice(0,6);
}

function inferSignals(text){
  const lower = text.toLowerCase();
  const out = [];
  if(/global|worldwide|international/.test(lower)) out.push("Global or cross-market scope");
  if(/built|launched|founded|created|scaled|grew|doubled/.test(lower)) out.push("Builder or scaler signal");
  if(/managed|led a team|team of \d+/.test(lower)) out.push("People leadership visible");
  if(/board|c-suite|executive committee/.test(lower)) out.push("Possible board or C-suite exposure");
  if(/transformation|turnaround|integration/.test(lower)) out.push("Transformation leadership signal");
  return out.length ? out : ["Further recruiter validation required"];
}

async function getPage(){
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  const [{result}] = await chrome.scripting.executeScript({
    target:{tabId:tab.id},
    func:()=>({
      title:document.title,
      h1:document.querySelector("h1")?.innerText || "",
      text:document.body.innerText.slice(0,30000),
      url:location.href
    })
  });
  return result;
}

$("analyze").addEventListener("click", async ()=>{
  $("status").textContent = "Analyzing...";
  try{
    const page = await getPage();
    const name = clean(page.h1) || clean(page.title.split(/[|–—-]/)[0]) || "Current Page";
    const text = clean(page.text);
    const roleMatch = text.match(/(Chief [A-Za-z &/-]+ Officer|CEO|CFO|COO|CTO|CPO|President|Vice President|VP|SVP|EVP|Director|Head of [A-Za-z &/-]+)\s+(?:at|@)\s+([A-Za-z0-9 .&'-]+)/i);
    const role = roleMatch ? `${clean(roleMatch[1])} at ${clean(roleMatch[2])}` : "Review source for current role and company";
    const expertise = inferExpertise(text);
    const signals = inferSignals(text);
    const summary = `${name} appears to be a senior leader with visible relevance across ${expertise.length ? expertise.join(", ") : "leadership and functional scope"}. Validate mandate, scale, outcomes, and mobility before outreach.`;
    const relevance = expertise.includes("Talent Intelligence") || expertise.includes("Executive Recruiting")
      ? "Strong relevance to executive recruiting, talent intelligence, and market-mapping work."
      : "Potential relevance requires validation against the search mandate.";

    brief = {name,role,summary,signals,expertise,relevance,url:page.url};

    $("name").textContent = name;
    $("role").textContent = role;
    $("summary").textContent = summary;
    $("signals").textContent = signals.map(x=>"• "+x).join("\n");
    $("expertise").textContent = expertise.length ? expertise.join(" • ") : "Not confidently detected";
    $("relevance").textContent = relevance;
    $("result").classList.remove("hidden");
    $("status").textContent = "Brief created";
  }catch(e){
    $("status").textContent = "Could not analyze this page.";
  }
});

$("copy").addEventListener("click", async ()=>{
  if(!brief) return;
  const text = `EXECUTIVE INTELLIGENCE BRIEF

Executive / Page: ${brief.name}

Current Role / Company:
${brief.role}

Executive Summary:
${brief.summary}

Career Signals:
${brief.signals.map(x=>"• "+x).join("\n")}

Functional Expertise:
${brief.expertise.join(", ") || "Not confidently detected"}

Potential Relevance:
${brief.relevance}

Recruiter Notes:
${$("notes").value}

Source:
${brief.url}`;
  await navigator.clipboard.writeText(text);
  $("status").textContent = "Brief copied";
});

$("save").addEventListener("click", async ()=>{
  if(!brief) return;
  const {savedPeople=[]} = await chrome.storage.local.get("savedPeople");
  savedPeople.unshift({...brief, notes:$("notes").value, savedAt:new Date().toISOString()});
  await chrome.storage.local.set({savedPeople:savedPeople.slice(0,50)});
  $("status").textContent = "Person saved locally";
});
